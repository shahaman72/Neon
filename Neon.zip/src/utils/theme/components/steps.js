import { StepsStyleConfig as Steps } from "chakra-ui-steps";
export const stepStyles = {
  components: {
    Steps,
  },
};
